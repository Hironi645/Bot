import { useState, useEffect } from 'react'
import { User, Calendar, Gamepad2, MapPin, MessageSquare, Send, Crown, ChevronDown, Navigation, Shield, Check } from 'lucide-react'
import './App.css'

interface FormData {
  nama: string
  umur: string
  usnHotel: string
  asalKota: string
  alasan: string
  admin: string
}

interface LocationData {
  lat: number | null
  lng: number | null
  address: string
  mode: 'auto' | 'manual'
}

function App() {
  const [showRules, setShowRules] = useState(true)
  const [rulesAccepted, setRulesAccepted] = useState(false)
  const [formData, setFormData] = useState<FormData>({
    nama: '',
    umur: '',
    usnHotel: '',
    asalKota: '',
    alasan: '',
    admin: ''
  })

  const [location, setLocation] = useState<LocationData>({
    lat: null,
    lng: null,
    address: '',
    mode: 'manual'
  })

  const [isLoadingLocation, setIsLoadingLocation] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  const admins = [
    { value: '', label: 'Pilih Admin' },
    { value: '6289504498328', label: 'Admin 1 — 0895-0449-8328' },
    { value: '6285824168807', label: 'Admin 2 — 0858-2416-8807' },
    { value: '6281318685216', label: 'Admin 3 — 0813-1868-5216' },
    { value: '6282157298268', label: 'Admin 4 — 0821-5729-8268' }
  ]

  const rules = [
    'saling menghormati dan menjaga sikap',
    'dilarang membuat keributan atau konflik',
    'gunakan bahasa yang sopan',
    'no spam / hoaks / link mencurigakan',
    'konten aman & pantas (NO 18+)',
    'patuhi admin & owner'
  ]

  const handleAcceptRules = () => {
    setRulesAccepted(true)
    setTimeout(() => setShowRules(false), 300)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const getCurrentLocation = () => {
    setIsLoadingLocation(true)
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords
          try {
            const response = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`)
            const data = await response.json()
            const address = data.display_name || `${latitude}, ${longitude}`
            setLocation({
              lat: latitude,
              lng: longitude,
              address: address,
              mode: 'auto'
            })
          } catch {
            setLocation({
              lat: latitude,
              lng: longitude,
              address: `${latitude}, ${longitude}`,
              mode: 'auto'
            })
          }
          setIsLoadingLocation(false)
        },
        (error) => {
          console.error('Error getting location:', error)
          alert('Tidak dapat mengakses lokasi. Silakan isi manual.')
          setIsLoadingLocation(false)
        }
      )
    } else {
      alert('Browser tidak mendukung geolokasi. Silakan isi manual.')
      setIsLoadingLocation(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.admin) {
      alert('Silakan pilih admin terlebih dahulu!')
      return
    }

    const locationText = location.mode === 'auto' && location.address
      ? `📍 Lokasi: ${location.address}`
      : formData.asalKota
        ? `📍 Asal Kota: ${formData.asalKota}`
        : '📍 Lokasi: -'

    const message = `*DEVIL REIGN — FORM MEMBER*
━━━━━━━━━━━━━━━

⌁ *Nama:* ${formData.nama || '-'}
⌁ *Umur:* ${formData.umur || '-'}
⌁ *USN Hotel Hideaway:* ${formData.usnHotel || '-'}
⌁ ${locationText}
⌁ *Alasan Bergabung:* ${formData.alasan || '-'}

━━━━━━━━━━━━━━━
*STATUS:* TERIMAKASIH SUDAH MENGISI
MENUNGGU PERSETUJUAN ADMIN
━━━━━━━━━━━━━━━
۝ Satu Reign, Satu Kekuasaan ۝`

    const whatsappUrl = `https://wa.me/${formData.admin}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, '_blank')
    setShowSuccess(true)
  }

  useEffect(() => {
    if (showSuccess) {
      const timer = setTimeout(() => setShowSuccess(false), 3000)
      return () => clearTimeout(timer)
    }
  }, [showSuccess])

  return (
    <div className="min-h-screen animated-bg flex items-center justify-center p-4">
      {/* Background Glow Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-red-800/10 rounded-full blur-[100px]" />
      </div>

      {/* Rules Modal */}
      {showRules && (
        <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 transition-opacity duration-300 ${rulesAccepted ? 'opacity-0' : 'opacity-100'}`}>
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => {}} />
          <div className="relative w-full max-w-md animate-modal-in">
            <div className="absolute -inset-1 bg-gradient-to-r from-red-600/40 via-red-500/30 to-red-600/40 rounded-3xl blur-lg" />
            <div className="relative glass-red rounded-3xl p-6 md:p-8">
              {/* Modal Header */}
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-red-500 to-red-700 mb-4 shadow-lg shadow-red-500/30">
                  <Shield className="w-7 h-7 text-white" />
                </div>
                <h2 className="text-xl md:text-2xl font-bold text-white tracking-wider">
                  PERATURAN DEVIL REIGN
                </h2>
                <div className="flex items-center justify-center gap-2 mt-2">
                  <div className="h-px w-10 bg-gradient-to-r from-transparent to-red-500/60" />
                  <span className="text-red-400 text-xs tracking-widest uppercase">Wajib Dibaca</span>
                  <div className="h-px w-10 bg-gradient-to-l from-transparent to-red-500/60" />
                </div>
              </div>

              {/* Rules List */}
              <div className="space-y-3 mb-8">
                {rules.map((rule, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-500/20 flex items-center justify-center text-red-400 text-xs font-bold border border-red-500/30">
                      {index + 1}
                    </span>
                    <p className="text-gray-300 text-sm pt-0.5">{rule}</p>
                  </div>
                ))}
              </div>

              {/* Divider */}
              <div className="flex items-center justify-center gap-3 mb-6">
                <div className="h-px flex-1 bg-gradient-to-r from-transparent via-red-500/40 to-transparent" />
              </div>

              {/* Accept Button */}
              <button
                onClick={handleAcceptRules}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-red-600 to-red-700 text-white font-semibold text-sm tracking-wide hover:from-red-500 hover:to-red-600 transition-all duration-300 shadow-lg shadow-red-600/30 hover:shadow-red-600/50 flex items-center justify-center gap-2 group"
              >
                <Check className="w-5 h-5 group-hover:scale-110 transition-transform" />
                SAYA SETUJU & LANJUTKAN
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Card */}
      <div className="relative w-full max-w-md">
        {/* Glow Effect */}
        <div className="absolute -inset-1 bg-gradient-to-r from-red-600/30 via-red-500/20 to-red-600/30 rounded-3xl blur-xl" />
        
        <div className="relative glass-red rounded-3xl p-6 md:p-8 glow-red">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-red-500 to-red-700 mb-4 shadow-lg shadow-red-500/30">
              <Crown className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white tracking-wider">
              DEVIL REIGN
            </h1>
            <div className="flex items-center justify-center gap-2 mt-2">
              <div className="h-px w-12 bg-gradient-to-r from-transparent to-red-500/60" />
              <span className="text-red-400 text-sm tracking-widest uppercase">Form Member</span>
              <div className="h-px w-12 bg-gradient-to-l from-transparent to-red-500/60" />
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Nama */}
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <User className="w-5 h-5 text-red-400/70 group-focus-within:text-red-400 transition-colors" />
              </div>
              <input
                type="text"
                name="nama"
                value={formData.nama}
                onChange={handleInputChange}
                placeholder="Nama"
                className="w-full pl-12 pr-4 py-3.5 rounded-xl glass-input text-white placeholder:text-gray-500 focus:outline-none text-sm"
              />
            </div>

            {/* Umur */}
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Calendar className="w-5 h-5 text-red-400/70 group-focus-within:text-red-400 transition-colors" />
              </div>
              <input
                type="number"
                name="umur"
                value={formData.umur}
                onChange={handleInputChange}
                placeholder="Umur"
                className="w-full pl-12 pr-4 py-3.5 rounded-xl glass-input text-white placeholder:text-gray-500 focus:outline-none text-sm"
              />
            </div>

            {/* USN Hotel Hideaway */}
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Gamepad2 className="w-5 h-5 text-red-400/70 group-focus-within:text-red-400 transition-colors" />
              </div>
              <input
                type="text"
                name="usnHotel"
                value={formData.usnHotel}
                onChange={handleInputChange}
                placeholder="USN Hotel Hideaway"
                className="w-full pl-12 pr-4 py-3.5 rounded-xl glass-input text-white placeholder:text-gray-500 focus:outline-none text-sm"
              />
            </div>

            {/* Location Section */}
            <div className="space-y-3">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setLocation(prev => ({ ...prev, mode: 'manual' }))}
                  className={`flex-1 py-2 px-3 rounded-lg text-xs font-medium transition-all ${
                    location.mode === 'manual'
                      ? 'bg-red-500/30 text-red-300 border border-red-500/50'
                      : 'bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10'
                  }`}
                >
                  <MapPin className="w-3 h-3 inline mr-1" />
                  Manual
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLocation(prev => ({ ...prev, mode: 'auto' }))
                    getCurrentLocation()
                  }}
                  className={`flex-1 py-2 px-3 rounded-lg text-xs font-medium transition-all ${
                    location.mode === 'auto'
                      ? 'bg-red-500/30 text-red-300 border border-red-500/50'
                      : 'bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10'
                  }`}
                >
                  <Navigation className="w-3 h-3 inline mr-1" />
                  Auto GPS
                </button>
              </div>

              {location.mode === 'manual' ? (
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <MapPin className="w-5 h-5 text-red-400/70 group-focus-within:text-red-400 transition-colors" />
                  </div>
                  <input
                    type="text"
                    name="asalKota"
                    value={formData.asalKota}
                    onChange={handleInputChange}
                    placeholder="Asal Kota"
                    className="w-full pl-12 pr-4 py-3.5 rounded-xl glass-input text-white placeholder:text-gray-500 focus:outline-none text-sm"
                  />
                </div>
              ) : (
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Navigation className={`w-5 h-5 ${isLoadingLocation ? 'animate-pulse text-red-400' : 'text-red-400/70'}`} />
                  </div>
                  <input
                    type="text"
                    value={isLoadingLocation ? 'Mendeteksi lokasi...' : location.address || 'Klik untuk mendapatkan lokasi'}
                    readOnly
                    onClick={getCurrentLocation}
                    className="w-full pl-12 pr-4 py-3.5 rounded-xl glass-input text-white text-sm cursor-pointer"
                  />
                </div>
              )}
            </div>

            {/* Alasan Bergabung */}
            <div className="relative group">
              <div className="absolute top-3.5 left-4 pointer-events-none">
                <MessageSquare className="w-5 h-5 text-red-400/70 group-focus-within:text-red-400 transition-colors" />
              </div>
              <textarea
                name="alasan"
                value={formData.alasan}
                onChange={handleInputChange}
                placeholder="Alasan Bergabung"
                rows={3}
                className="w-full pl-12 pr-4 py-3.5 rounded-xl glass-input text-white placeholder:text-gray-500 focus:outline-none text-sm resize-none"
              />
            </div>

            {/* Admin Select */}
            <div className="relative">
              <select
                name="admin"
                value={formData.admin}
                onChange={handleInputChange}
                className="w-full px-4 py-3.5 rounded-xl glass-input text-white text-sm appearance-none focus:outline-none cursor-pointer"
              >
                {admins.map((admin) => (
                  <option key={admin.value} value={admin.value} className="bg-gray-900">
                    {admin.label}
                  </option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none">
                <ChevronDown className="w-5 h-5 text-red-400/70" />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-4 rounded-xl bg-gradient-to-r from-red-600 to-red-700 text-white font-semibold text-sm tracking-wide hover:from-red-500 hover:to-red-600 transition-all duration-300 shadow-lg shadow-red-600/30 hover:shadow-red-600/50 flex items-center justify-center gap-2 group"
            >
              <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              KIRIM KE WHATSAPP
            </button>
          </form>

          {/* Footer */}
          <div className="mt-8 text-center">
            <div className="flex items-center justify-center gap-3 mb-3">
              <div className="h-px flex-1 bg-gradient-to-r from-transparent via-red-500/40 to-transparent" />
            </div>
            <p className="text-red-300/80 text-xs font-medium tracking-wider">
              STATUS: TERIMAKASIH SUDAH MENGISI
            </p>
            <p className="text-gray-500 text-xs mt-1">
              MENUNGGU PERSETUJUAN ADMIN
            </p>
            <div className="flex items-center justify-center gap-3 mt-3">
              <div className="h-px flex-1 bg-gradient-to-r from-transparent via-red-500/40 to-transparent" />
            </div>
            <p className="text-red-400/60 text-xs mt-3 tracking-widest">
              ۝ Satu Reign, Satu Kekuasaan ۝
            </p>
          </div>
        </div>
      </div>

      {/* Credit - by Hironi */}
      <div className="fixed bottom-4 left-0 right-0 text-center">
        <p className="text-gray-500/60 text-xs tracking-wider">
          made with <span className="text-red-500/60">♥</span> by <span className="text-red-400/80 font-medium">Hironi</span>
        </p>
      </div>

      {/* Success Toast */}
      {showSuccess && (
        <div className="fixed bottom-12 left-1/2 -translate-x-1/2 glass-red px-6 py-3 rounded-full text-white text-sm font-medium animate-in fade-in slide-in-from-bottom-4">
          Pesan berhasil dikirim!
        </div>
      )}
    </div>
  )
}

export default App
